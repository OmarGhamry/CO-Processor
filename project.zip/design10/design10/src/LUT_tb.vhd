library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_lut is
end entity;

architecture behavior of tb_lut is	

    signal LUTin  : std_logic_vector(7 downto 0) := (others => '0');
    signal LUTout : std_logic_vector(7 downto 0);
begin

    UUT: entity work.nonlinear_lut
        port map(
            LUTin  => LUTin,
            LUTout => LUTout
        );
 
    process
    begin

		-- Test 1
		LUTin <= "00000000";         
		wait for 20 ns;
		        
		-- Test 2       
		LUTin <= "11111111";         
		wait for 20 ns;
		       
		-- Test 3        
		LUTin <= "01010101";         
		wait for 20 ns;
		        
		-- Test 4        
		LUTin <= "10101010";         
		wait for 20 ns;
		       
		-- Test 5       
		LUTin <= "00110011";         
		wait for 20 ns;
		
		-- Test 6        
		LUTin <= "11001100";         
		wait for 20 ns;

        wait;
    end process;

end architecture;