library ieee;
use ieee.std_logic_1164.all;

entity CoProcessor_tb is
end entity;

architecture sim of CoProcessor_tb is

    signal ctrl : std_logic_vector(3 downto 0) := (others => '0');
    signal clk  : std_logic := '0';
    signal rst  : std_logic := '0';

    signal Ra,Rb,Rd : std_logic_vector(3 downto 0) := (others => '0');

begin

    DUT : entity Co_Processor
    port map(
        ctrl => ctrl,
        clk  => clk,
        rst  => rst,
        Ra   => Ra,
        Rb   => Rb,
        Rd   => Rd
    );

    
 
   
    clk_process : process
    begin
        while true loop
            clk <= '0';
            wait for 5 ns;

            clk <= '1';
            wait for 5 ns;
        end loop;
    end process;

   
   
    
    rst_process : process
    begin
        rst <= '0';
        wait for 130 ns;
		
		rst <= '1';
        wait for 40 ns;
		
        rst <= '0';
        wait;
    end process;


    stim_process : process
    begin

 
        wait for 35 ns;

    
        -- NOP

        Ra   <= "0000";
        Rb   <= "0000";
        Rd   <= "0000";
        ctrl <= "0111";

        wait for 20 ns;

       
        -- ADD R5
      
        Ra   <= "0101";
        Rb   <= "0100";
        Rd   <= "1100";
        ctrl <= "0000";

        wait for 20 ns;

        
        -- XOR R1,R8,R7
   
        Ra   <= "1100";
        Rb   <= "1000";
        Rd   <= "0111";
        ctrl <= "0100";

        wait for 20 ns;

      
        -- ROR4

        Ra   <= "0001";
        Rb   <= "1100";
        Rd   <= "0000";
        ctrl <= "1001";

        wait for 20 ns;

        
        -- SLL8
   
        Ra   <= "0001";
        Rb   <= "1001";
        Rd   <= "0011";
        ctrl <= "1010";

        wait for 20 ns;

    
        -- ADD R0,R7,R10
  
        Ra   <= "0000";
        Rb   <= "0111";
        Rd   <= "1010";
        ctrl <= "0000";

        wait for 20 ns;

       
        -- SUB R7,R3,R12
   
        Ra   <= "0111";
        Rb   <= "0011";
        Rd   <= "1100";
        ctrl <= "0001";

        wait for 20 ns;


        -- NOP
       
        Ra   <= "0111";
        Rb   <= "0011";
        Rd   <= "1100";
        ctrl <= "0111";

        wait for 20 ns;

    
        -- LUT 

        Ra   <= "1100";
        Rb   <= "1010";
        Rd   <= "1001";
        ctrl <= "1011";

        wait for 20 ns;

      
        -- NOP
    
        Ra   <= "1100";
        Rb   <= "1010";
        Rd   <= "1001";
        ctrl <= "0111";

        wait for 20 ns;

      
        -- LUT R9,R2
     
        Ra   <= "1001";
        Rb   <= "1010";
        Rd   <= "0010";
        ctrl <= "1011";

        wait for 40 ns;

        wait;

    end process;

end architecture;