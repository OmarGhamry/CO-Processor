library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity reg_file_tb is
end entity;

architecture sim of reg_file_tb is 

	signal clk ,rst  :  std_logic :='0';
	signal en :  std_logic :='1';

	signal ra , rb , rd :  std_logic_vector(3 downto 0):= "0000";

	signal res: std_logic_vector(15 downto 0):= x"0000";

	signal ABUS,BBUS:  std_logic_vector(15 downto 0):= x"0000";  
	
begin 	

	reg1: entity reg_file
		port map(
			clk  => clk,
			rst  => rst,
			en   => en,
			ra   => ra,
			rb   => rb,
			rd   => rd,
			res  => res,
			ABUS => ABUS,
			BBUS => BBUS
		);


	clk <= not clk after 5 ns;


	en_process : process
	begin  	
		en <= '1';
		wait for 20 ns;

		en <= '0';
		wait for 10 ns;
	end process;  


	rst_process : process 
	begin  	
		rst <= '0';
		wait for 80 ns;

		rst <= '1';
		wait for 45 ns;
	end process;


	process 
	begin 

	
		wait for 2 ns;

		rd  <= "0001";
		res <= x"1111";

		wait for 10 ns;


		rd  <= "0010";
		res <= x"5555";

		wait for 10 ns;


		ra  <= "0001";
		rb  <= "0010";

		rd  <= "0110";
		res <= x"BBB1";	

		wait for 10 ns;

		ra <= "0100";
		rb <= "0010";

		wait for 10 ns;	   	


		ra <= "0110";
		rb <= "0000";

		wait for 10 ns;


		rd  <= "0011";
		res <= x"F0F0";

		ra  <= "0011";  
		rb  <= "0110";

		wait for 10 ns;	  	

	
		rd  <= "1000";
		res <= x"A0A0";

		ra  <= "1110";  
		rb  <= "1000";

		wait for 10 ns;

		wait;

	end process;   

end architecture;


