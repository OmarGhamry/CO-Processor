					  
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity reg_file is
    port(
        clk, rst, en : in  std_logic := '0';
        ra, rb, rd   : in  std_logic_vector(3 downto 0);
        res          : in  std_logic_vector(15 downto 0);
        ABUS, BBUS   : out std_logic_vector(15 downto 0)
    );
end entity;

architecture behaviour of reg_file is
    type reg_array is array (0 to 15) of std_logic_vector(15 downto 0);
    signal REG : reg_array := (
        0  => x"0024",1  => x"b456",
        2  => x"3c07",3  => x"4b15",
		4  => x"1354",5  => x"f407",
        6  => x"daa5",7  => x"f123",
        8  => x"ba54",9  => x"baa0",
		10 => x"c902",11 => x"100b",
		12 => x"c000",13 => x"a902",
        14 => x"1564",15 => x"A030",
        others => (others => '0')
    );

begin

    -- READ (Asynchronous)
    ABUS <= REG(to_integer(unsigned(ra)));
    BBUS <= REG(to_integer(unsigned(rb)));

    -- WRITE + RESET (Synchronous)
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                REG <= (others => (others => '0')); -- ? clears ALL registers
            elsif en = '1' then
                REG(to_integer(unsigned(rd))) <= res;
            end if;
        end if;
    end process;

end architecture;